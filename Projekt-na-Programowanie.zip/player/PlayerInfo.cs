public class PlayerInfo{
    public int Id;
    public string Name;
    public int Score;
}